#!/usr/bin/env python3
"""Independent exact check of the codegree-five two-hub lemma.

Formal finite claim checked here.

Let H be a labelled graph on C={0,...,4}.  For A subset C, let L(H,A)
be the seven-vertex graph on C union {r,a}: r is complete to C, a has
neighbourhood A, ra is absent, and C induces H.

For R subset E(H), let q be the vertex-cover number of H-R and let p(R)
be the largest edge-disjoint packing among the triangles uvx (x in C),
uxy and vxy (xy in R).  The template inequality is

    3 + |R| + 2q <= 2p(R).

The script checks:
  (1) exactly 32 of the 1024 labelled H have no template R, in exactly
      five isomorphism classes: the empty graph (mask 0x000), the star
      K_{1,4} (0x00F), K_3 + K_2 (0x0B8), the bowtie K_1 join 2K_2
      (0x0CF), and K_5 (0x3FF), with 1+5+10+15+1 = 32 labelled copies;
  (2) outside K5, every nonempty boundary extension of those failures is
      WKE under the literal matching/vertex-cover definition;
  (3) every H admitting a connected non-WKE extension is template-reducible,
      except K5, for which the displayed seven-triangle Fano reduction works;
  (4) every produced (S,X) satisfies all three of Puleo's reduction conditions
      for every ordered boundary pair (A,B), both without and with the one
      possible ambient A--B edge, using exact edge incidence.

This is standard-library-only and uses no floating point or optimizer.
It checks the finite local lemma, not Tuza T1 or the ambient use of Puleo's
minimal-counterexample theorem.
"""

from collections import Counter
from functools import cache
from itertools import combinations, permutations


C = tuple(range(5))
U, V, AA, BB = 5, 6, 7, 8
CORE_PAIRS = tuple(combinations(C, 2))
CORE_INDEX = {e: i for i, e in enumerate(CORE_PAIRS)}
PERMS = tuple(permutations(C))


def require(condition, label):
    if not condition:
        raise AssertionError(label)
    print(f"PASS {label}")


def core_edges(mask):
    return frozenset(e for i, e in enumerate(CORE_PAIRS) if mask >> i & 1)


def permute_mask(mask, perm):
    answer = 0
    for x, y in core_edges(mask):
        e = tuple(sorted((perm[x], perm[y])))
        answer |= 1 << CORE_INDEX[e]
    return answer


def canonical(mask):
    return min(permute_mask(mask, p) for p in PERMS)


def is_matching(edges):
    used = set()
    for x, y in edges:
        if x in used or y in used:
            return False
        used.update((x, y))
    return True


def link_edges(core, boundary):
    # On 0,...,4,r=5,a=6.  These labels are local to the WKE test.
    r, a = 5, 6
    answer = set(core_edges(core))
    answer.update((x, r) for x in C)
    answer.update((x, a) for x in C if boundary >> x & 1)
    return frozenset(tuple(sorted(e)) for e in answer)


def wke_witness(edges):
    """Return a literal (M,Q) WKE witness, or None."""
    vertices = tuple(range(7))
    edge_tuple = tuple(sorted(edges))
    for msize in range(4):
        for M in combinations(edge_tuple, msize):
            if not is_matching(M):
                continue
            remainder = set(edge_tuple) - set(M)
            for qsize in range(msize + 1):
                for Q in combinations(vertices, qsize):
                    q = set(Q)
                    if all(x in q or y in q for x, y in remainder):
                        return tuple(M), tuple(Q)
    return None


@cache
def minimum_vertex_cover(core):
    edges = core_edges(core)
    for size in range(6):
        for Q in combinations(C, size):
            q = set(Q)
            if all(x in q or y in q for x, y in edges):
                return tuple(Q)
    raise AssertionError("finite vertex cover not found")


def triangle_edges(t):
    return frozenset(tuple(sorted(e)) for e in combinations(t, 2))


def template_triangles(rim):
    answer = [(U, V, x) for x in C]
    for x, y in core_edges(rim):
        answer.append((U, x, y))
        answer.append((V, x, y))
    return tuple(tuple(sorted(t)) for t in answer)


@cache
def maximum_template_packing(rim):
    """Return an exact largest hub-only triangle packing in K2 join rim."""
    triangles = template_triangles(rim)
    edge_sets = tuple(triangle_edges(t) for t in triangles)
    best = ()

    def search(i, used, chosen):
        nonlocal best
        if len(chosen) + len(triangles) - i <= len(best):
            return
        if i == len(triangles):
            if len(chosen) > len(best):
                best = tuple(chosen)
            return
        search(i + 1, used, chosen)
        if not (used & edge_sets[i]):
            search(i + 1, used | edge_sets[i], chosen + (triangles[i],))

    search(0, frozenset(), ())
    return best


@cache
def template_data(core):
    """Return one (R,Q,S) satisfying the template inequality, or None."""
    rim = core
    while True:
        Q = minimum_vertex_cover(core & ~rim)
        S = maximum_template_packing(rim)
        if 3 + rim.bit_count() + 2 * len(Q) <= 2 * len(S):
            return rim, Q, S
        if rim == 0:
            return None
        rim = (rim - 1) & core


def local_edges(core, boundary_a, boundary_b, include_ab=False):
    answer = set(core_edges(core))
    answer.add((U, V))
    answer.update(tuple(sorted((U, x))) for x in C)
    answer.update(tuple(sorted((V, x))) for x in C)
    answer.add(tuple(sorted((U, AA))))
    answer.add(tuple(sorted((V, BB))))
    answer.update(tuple(sorted((AA, x))) for x in C if boundary_a >> x & 1)
    answer.update(tuple(sorted((BB, x))) for x in C if boundary_b >> x & 1)
    if include_ab:
        answer.add(tuple(sorted((AA, BB))))
    return frozenset(answer)


def all_triangles(edges):
    vertices = tuple(range(9))
    return tuple(
        t for t in combinations(vertices, 3)
        if triangle_edges(t) <= edges
    )


def template_reduction(core, data):
    rim, Q, S = data
    X = set(core_edges(rim))
    X.update({tuple(sorted((U, V))), tuple(sorted((U, AA))), tuple(sorted((V, BB)))})
    X.update(tuple(sorted((U, x))) for x in Q)
    X.update(tuple(sorted((V, x))) for x in Q)
    return tuple(S), frozenset(X)


def fano_reduction():
    S = (
        (U, V, 0),
        (U, 1, 2),
        (U, 3, 4),
        (V, 1, 3),
        (V, 2, 4),
        (0, 1, 4),
        (0, 2, 3),
    )
    X = set(core_edges((1 << 10) - 1))
    X.update({tuple(sorted((U, V))), tuple(sorted((U, AA))), tuple(sorted((V, BB)))})
    return tuple(tuple(sorted(t)) for t in S), frozenset(X)


def literal_reduction(core, boundary_a, boundary_b, reduction, include_ab=False):
    """Check all three local reducibility conditions for V0={u,v}."""
    S, X = reduction
    edges = local_edges(core, boundary_a, boundary_b, include_ab)
    if not X <= edges:
        return False
    used = set()
    for t in S:
        te = triangle_edges(t)
        if not te <= edges or used & te:
            return False
        used.update(te)
    if len(X) > 2 * len(S):
        return False
    for t in all_triangles(edges):
        if (U in t or V in t) and not (triangle_edges(t) & X):
            return False
    for t in S:
        for e in triangle_edges(t):
            if U not in e and V not in e and e not in X:
                return False
    return True


def main():
    require(len(CORE_PAIRS) == 10, "C_five_vertex_edge_universe")

    failures = [core for core in range(1 << 10) if template_data(core) is None]
    failure_counts = Counter(canonical(core) for core in failures)
    expected_counts = Counter({0x000: 1, 0x00F: 5, 0x0B8: 10, 0x0CF: 15, 0x3FF: 1})
    require(len(failures) == 32, "T_exactly_32_labelled_template_failures")
    require(failure_counts == expected_counts, "T_failure_classes_empty_star_K3plusK2_bowtie_K5")

    # The first four failure classes cannot occur at either hub of a minimal
    # counterexample: every connected extension (equivalently boundary nonempty)
    # is WKE.  K5 is the unique template failure surviving this filter.
    nonclique_failures = [core for core in failures if core != 0x3FF]
    checked_wke_links = 0
    for core in nonclique_failures:
        for boundary in range(1, 32):
            require_witness = wke_witness(link_edges(core, boundary))
            if require_witness is None:
                raise AssertionError(("non-WKE exceptional link", core, boundary))
            checked_wke_links += 1
    require(checked_wke_links == 31 * 31, "W_all_961_nonclique_exception_links_are_WKE")
    require(
        all(wke_witness(link_edges(0x3FF, boundary)) is None for boundary in range(1, 32)),
        "W_K5_extensions_are_non_WKE",
    )

    possible = []
    for core in range(1 << 10):
        if any(wke_witness(link_edges(core, boundary)) is None for boundary in range(1, 32)):
            possible.append(core)
    possible_classes = {canonical(core) for core in possible}
    expected_possible = {
        0x036, 0x037, 0x03B, 0x03E, 0x03F, 0x07E, 0x07F, 0x0B7,
        0x0BB, 0x0BF, 0x0DC, 0x0DD, 0x0DF, 0x0FE, 0x0FF, 0x1EF,
        0x1FF, 0x3FF,
    }
    require(possible_classes == expected_possible, "W_exact_18_possible_unlabelled_cores")
    require(len(possible) == 548, "W_exact_548_possible_labelled_cores")

    # Literal ambient check.  A template witness is boundary-independent; K5
    # uses Fano.  Check every ordered A,B pair, not only the non-WKE ones, and
    # check both states of the ambient edge ab discarded by the local model.
    checked_configurations = 0
    for core in possible:
        reduction = fano_reduction() if core == 0x3FF else template_reduction(core, template_data(core))
        for boundary_a in range(32):
            for boundary_b in range(32):
                for include_ab in (False, True):
                    if not literal_reduction(
                        core, boundary_a, boundary_b, reduction, include_ab
                    ):
                        raise AssertionError(
                            ("bad literal reduction", core, boundary_a, boundary_b, include_ab)
                        )
                    checked_configurations += 1
    require(
        checked_configurations == 548 * 32 * 32 * 2,
        "R_all_1122304_boundary_pairs_and_ambient_ab_states_checked",
    )
    print(f"COUNT literal_reduction_configurations={checked_configurations}")
    print("ALL CODEGREE-FIVE CHECKS PASSED")


if __name__ == "__main__":
    main()
