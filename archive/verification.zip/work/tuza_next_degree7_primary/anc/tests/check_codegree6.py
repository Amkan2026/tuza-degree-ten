#!/usr/bin/env python3
"""Exact standalone check of the codegree-six two-hub reduction.

The common-neighbour set is [6], with its 15 possible rim edges encoded by
bitmasks.  H is the actual common-neighbour graph and R is the set of rim
edges put into both the packing substrate and the local cover.

Only Python's standard library and exact integer arithmetic are used.
"""

from itertools import combinations


C = tuple(range(6))
U, V = 6, 7
RIM_EDGES = tuple(combinations(C, 2))
RIM_INDEX = {e: i for i, e in enumerate(RIM_EDGES)}
FULL = (1 << len(RIM_EDGES)) - 1


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def rim_mask(edges):
    ans = 0
    for a, b in edges:
        if a > b:
            a, b = b, a
        require((a, b) in RIM_INDEX, f"bad rim edge {(a, b)}")
        ans |= 1 << RIM_INDEX[(a, b)]
    return ans


def edge_set(mask):
    return {RIM_EDGES[i] for i in range(15) if mask >> i & 1}


INCIDENT = []
for qmask in range(1 << 6):
    mask = 0
    for i, (a, b) in enumerate(RIM_EDGES):
        if (qmask >> a & 1) or (qmask >> b & 1):
            mask |= 1 << i
    INCIDENT.append(mask)


MATCHINGS = []
for mask in range(1 << 15):
    used = 0
    good = True
    for i, (a, b) in enumerate(RIM_EDGES):
        if not (mask >> i & 1):
            continue
        if (used >> a & 1) or (used >> b & 1):
            good = False
            break
        used |= (1 << a) | (1 << b)
    if good:
        MATCHINGS.append(mask)

require(len(MATCHINGS) == 76, "wrong number of matchings of K6")


def precompute_two_matchings():
    """Best total size of two edge-disjoint matchings contained in each R."""
    score = [-1] * (1 << 15)
    cert = [None] * (1 << 15)
    for m1 in MATCHINGS:
        for m2 in MATCHINGS:
            if m1 & m2:
                continue
            union = m1 | m2
            value = m1.bit_count() + m2.bit_count()
            if value > score[union]:
                score[union] = value
                cert[union] = (m1, m2)

    # Subset maximum transform, retaining a literal pair of matchings.
    for bit in range(15):
        flag = 1 << bit
        for mask in range(1 << 15):
            if mask & flag and score[mask ^ flag] > score[mask]:
                score[mask] = score[mask ^ flag]
                cert[mask] = cert[mask ^ flag]
    return score, cert


TWO_SCORE, TWO_CERT = precompute_two_matchings()


def packing_certificate(rmask):
    """Return p(R) and a hub-only packing attaining it.

    A packing either omits uv and is two edge-disjoint rim matchings, or
    contains one uvx, after which both matchings avoid x.
    """
    best = TWO_SCORE[rmask]
    m1, m2 = TWO_CERT[rmask]
    triangles = [(U, a, b) for a, b in edge_set(m1)]
    triangles += [(V, a, b) for a, b in edge_set(m2)]

    for x in C:
        allowed = rmask & ~INCIDENT[1 << x]
        value = 1 + TWO_SCORE[allowed]
        if value > best:
            best = value
            m1, m2 = TWO_CERT[allowed]
            triangles = [(U, V, x)]
            triangles += [(U, a, b) for a, b in edge_set(m1)]
            triangles += [(V, a, b) for a, b in edge_set(m2)]
    require(len(triangles) == best, "packing certificate has wrong size")
    return best, triangles


P_SCORE = [0] * (1 << 15)
P_TRIANGLES = [None] * (1 << 15)
for rmask in range(1 << 15):
    P_SCORE[rmask], P_TRIANGLES[rmask] = packing_certificate(rmask)


VC_SIZE = [7] * (1 << 15)
VC_SET = [None] * (1 << 15)
for hmask in range(1 << 15):
    for qmask in sorted(range(1 << 6), key=lambda q: (q.bit_count(), q)):
        if hmask & ~INCIDENT[qmask] == 0:
            VC_SIZE[hmask] = qmask.bit_count()
            VC_SET[hmask] = qmask
            break
    require(VC_SET[hmask] is not None, "vertex cover not found")


def canon_edge(a, b):
    return (a, b) if a < b else (b, a)


def triangle_edges(t):
    a, b, c = t
    return {canon_edge(a, b), canon_edge(a, c), canon_edge(b, c)}


def local_edges(hmask):
    edges = edge_set(hmask)
    edges.add((U, V))
    for x in C:
        edges.add(canon_edge(U, x))
        edges.add(canon_edge(V, x))
    return edges


def verify_witness(hmask, rmask, p, triangles, qmask):
    require(rmask & ~hmask == 0, "R is not a subgraph of H")
    require(hmask & ~rmask & ~INCIDENT[qmask] == 0,
            "Q does not cover H-R")

    graph = local_edges(hmask)
    used = set()
    for t in triangles:
        te = triangle_edges(t)
        require(te <= graph, f"nontriangle in S: {t}")
        require(not (te & used), f"packing-edge collision at {t}")
        used |= te
    require(len(triangles) == p == P_SCORE[rmask], "nonmaximum p certificate")

    xedges = edge_set(rmask)
    xedges.add((U, V))
    for x in C:
        if qmask >> x & 1:
            xedges.add(canon_edge(U, x))
            xedges.add(canon_edge(V, x))
    cost = 1 + rmask.bit_count() + 2 * qmask.bit_count()
    require(len(xedges) == cost, "X cardinality mismatch")
    require(cost <= 2 * p, "reducibility budget fails")

    # Enumerate the literal local triangle family, including triangles wholly
    # in the common core (which need not be hit because they miss both hubs).
    for t in combinations(range(8), 3):
        te = triangle_edges(t)
        if U not in t and V not in t:
            continue
        if te <= graph:
            require(te & xedges, f"unhit hub triangle {t}")

    for e in used:
        if U not in e and V not in e:
            require(e in xedges, f"outside packing edge {e} omitted from X")
    return cost


def find_witness(hmask):
    rmask = hmask
    while True:
        remainder = hmask & ~rmask
        q = VC_SIZE[remainder]
        p = P_SCORE[rmask]
        if 1 + rmask.bit_count() + 2 * q <= 2 * p:
            return rmask, q, p, VC_SET[remainder], P_TRIANGLES[rmask]
        if rmask == 0:
            return None
        rmask = (rmask - 1) & hmask


def best_template_margin(hmask):
    """Maximum budget slack over every R subseteq H."""
    best = -1
    rmask = hmask
    while True:
        remainder = hmask & ~rmask
        margin = (
            2 * P_SCORE[rmask]
            - 1
            - rmask.bit_count()
            - 2 * VC_SIZE[remainder]
        )
        best = max(best, margin)
        if rmask == 0:
            return best
        rmask = (rmask - 1) & hmask


def verify_fano_k6():
    # Five selected common vertices form the Fano K7 with the two hubs; the
    # sixth common vertex w is hit by both boundary spokes.
    a, b, c, d, e, w = C
    triangles = [
        (U, V, a),
        (U, b, c),
        (U, d, e),
        (V, b, d),
        (V, c, e),
        (a, b, e),
        (a, c, d),
    ]
    core = {a, b, c, d, e}
    xedges = {canon_edge(x, y) for x, y in combinations(core, 2)}
    xedges |= {(U, V), canon_edge(U, w), canon_edge(V, w)}
    require(len(triangles) == 7 and len(xedges) == 13, "Fano sizes wrong")
    graph = local_edges(FULL)
    used = set()
    for t in triangles:
        te = triangle_edges(t)
        require(te <= graph and not te & used, "bad Fano packing")
        used |= te
    require(len(used) == 21, "Fano triples do not decompose K7")
    require(len(xedges) <= 2 * len(triangles), "Fano budget fails")
    for t in combinations(range(8), 3):
        te = triangle_edges(t)
        if (U in t or V in t) and te <= graph:
            require(te & xedges, f"Fano X misses hub triangle {t}")
    for e0 in used:
        if U not in e0 and V not in e0:
            require(e0 in xedges, f"Fano outside edge {e0} omitted")


def main():
    require(P_SCORE[0] == 1, "uv-triangle baseline missing")
    require(P_SCORE[FULL] == 6, "hub-only K6 packing optimum changed")
    require(VC_SIZE[0] == 0 and VC_SIZE[FULL] == 5,
            "vertex-cover anchors failed")

    solved = 0
    margin_counts = {}
    rsize_counts = {}
    chosen_exact = []
    best_margin_counts = {}
    for hmask in range(1 << 15):
        witness = find_witness(hmask)
        if hmask == FULL:
            require(witness is None,
                    "K6 unexpectedly has a hub-only inequality witness")
            continue
        require(witness is not None, f"no witness for H mask {hmask}")
        rmask, q, p, qmask, triangles = witness
        cost = verify_witness(hmask, rmask, p, triangles, qmask)
        margin = 2 * p - cost
        margin_counts[margin] = margin_counts.get(margin, 0) + 1
        rsize_counts[rmask.bit_count()] = rsize_counts.get(rmask.bit_count(), 0) + 1
        if margin == 0:
            chosen_exact.append(hmask)
        best_margin = best_template_margin(hmask)
        best_margin_counts[best_margin] = best_margin_counts.get(best_margin, 0) + 1
        solved += 1

    require(solved == (1 << 15) - 1, "wrong solved-H count")
    verify_fano_k6()

    # Hostile mutation: K6 really is exceptional for the hub-only formula.
    for rmask in range(1 << 15):
        remainder = FULL & ~rmask
        require(1 + rmask.bit_count() + 2 * VC_SIZE[remainder]
                > 2 * P_SCORE[rmask],
                "hub-only K6 hostile did not fail")

    print(f"PASS matchings_K6={len(MATCHINGS)}")
    print("PASS packing_formula_all_R_masks=32768")
    print("PASS vertex_cover_all_masks=32768")
    print(f"PASS all_noncomplete_H_reduced={solved}")
    print(f"PASS chosen_witness_exact_budget_H_count={len(chosen_exact)}")
    print("PASS chosen_witness_margin_hist=" + ",".join(
        f"{key}:{margin_counts[key]}" for key in sorted(margin_counts)))
    require(
        best_margin_counts == {0: 155, 1: 3683, 2: 11367, 3: 13830, 4: 3267, 5: 465},
        "intrinsic best-margin distribution changed",
    )
    print("PASS intrinsic_best_margin_hist=" + ",".join(
        f"{key}:{best_margin_counts[key]}" for key in sorted(best_margin_counts)))
    print("PASS intrinsically_tight_noncomplete_H_count=155")
    print("PASS chosen_R_size_hist=" + ",".join(
        f"{key}:{rsize_counts[key]}" for key in sorted(rsize_counts)))
    print("PASS K6_hub_only_hostile_all_R=32768")
    print("PASS K6_Fano_7_triangles_13_edges")
    print("ALL CODEGREE-SIX CHECKS PASSED")


if __name__ == "__main__":
    main()
