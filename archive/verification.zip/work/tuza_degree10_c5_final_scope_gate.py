"""Final source-bound C5 and foundation scope gate; no search or optimizer."""
import hashlib
import json
from pathlib import Path

W = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    c5_path = W / 'tuza_degree10_c5_verification_manifest.json'
    assert sha(c5_path) == '1e0c695b77db2db5ecc051584ee90104cf045d97433e8133bab9f8035e68c79c'
    c5 = json.loads(c5_path.read_bytes())
    bound = {}
    for name, binding in c5['bindings'].items():
        path = Path(binding['bound_snapshot'])
        data = path.read_bytes()
        assert len(data) == binding['bytes']
        assert hashlib.sha256(data).hexdigest() == binding['sha256']
        bound[name] = binding['sha256']
    assert c5['status'] == 'PASS' and c5['complete_graph_scope']
    assert not c5['complete_pair_scope']
    assert c5['global_minimum_degree_premise'] == 5
    assert c5['selected_endpoint_degrees'] == [7,8,9,10]
    assert c5['required_new_ordinary_graph_rows'] == 97
    assert c5['verified_new_ordinary_pair_rows'] == 94
    assert c5['new_pair_rows_canonical_side_pairs'] == 1512872129
    assert c5['all_new_ordinary_graph_rows_canonical_side_pairs'] == 1513351848
    assert c5['preferred_new_ordinary_pair_intervals'] == 2315
    rows = c5['domain_reports']
    assert len(rows) == 97 and len({(tuple(r['degrees']),r['core']) for r in rows}) == 97
    assert all(r['status'] == 'PASS' for r in rows)
    assert c5['graph_cases_unclosed'] == 0
    assert c5['unknown_solver_status_used_as_infeasible'] is False
    assert c5['star']['all_four_ambient_ten_hub_triples_verified']
    assert c5['star']['graph_cases_unclosed'] == 0
    assert not c5['old_transfers']['old_ambient_nine_star_graph_tail_used']
    assert c5['old_transfers']['corrected_degree_eight_intervals'] == 30
    assert c5['old_transfers']['ordinary_degree_nine_rows'] == 69

    sr_path = W / 'tuza_degree10_subcubic_link_basis_verified.json'
    sr = json.loads(sr_path.read_bytes())
    assert sr['result'] == 'PASS'
    assert sr['complete_min2_domain_types'] == 702
    assert sr['whole_connected_types'] == 2561
    assert sr['proper_colorings_converted_to_literal_WKE'] == 660
    assert sr['direct_WKE_witnesses'] == 40
    assert sr['only_remaining_types'] == ['P','R']
    subs = {
        'tuza_degree10_subcubic_link_basis.json.gz': 'payload_sha256',
        'tuza_degree10_subcubic_branch_proof.txt': 'proof_sha256',
        'tuza_degree10_subcubic_link_basis_check.py': 'source_sha256',
        'tuza_book3_condensed_root_check.py': 'helper_source_sha256',
    }
    sb = {name: sha(W/name) for name in subs}
    assert all(sb[name] == sr[field] for name,field in subs.items())
    sb[sr_path.name] = sha(sr_path)
    peer = W / 'tuza_degree10_subcubic_branch_peer_audit.txt'
    sb[peer.name] = sha(peer)

    report = {
        'status': 'PASS_C5_AND_FOUNDATION_SCOPE_GATE',
        'complete_full_degree_ten_theorem_claimed': False,
        'c5_manifest_sha256': sha(c5_path),
        'all_c5_manifest_bound_bytes_rechecked': len(bound),
        'c5_bindings': bound,
        'global_minimum_degree': 5,
        'global_minimum_degree_seven_applies_only_to_maximum_codegree_four_branch': True,
        'selected_codegree_five_degree_six_endpoint': 'ambient-independent Fano and four-private-vertex proof, with unused formal isolates and trimmed cover spokes',
        'thin_six_degree_ten_disconnected_link': 'explicit W4 component spoke reduction included in proof SHA1e18dc033d12f398d754e15e501569ee86884d71682483a1b963a52037863644',
        'selected_endpoint_link_connected_for_codegree_at_least_five': 'its component contains partner and at least five common neighbors; any other robust component has at least five vertices, exceeding degree ten',
        'old_degree_eight_c5_transfer': 'all30 corrected endpoint-pair intervals, with every packed outer edge selected',
        'old_degree_nine_c5_transfer': '69 ordinary endpoint-pair rows; no ambient-nine larger-hub star tail transferred',
        'fresh_ambient_ten_c5_star_hub_degree_triples': [[9,9,9],[9,9,10],[9,10,10],[10,10,10]],
        'new_c5_ordinary_graph_domains': 97,
        'new_c5_ordinary_pair_rows': 94,
        'new_c5_graph_special_rows': 3,
        'new_c5_selected_star_graph_domain': 1,
        'c5_graph_cases_unclosed': 0,
        'c5_universal_pair_completion_claimed': False,
        'standalone_subcubic_branch_bindings': sb,
        'standalone_subcubic_branch_human_review': 'PASS: coloring implication, leaf induction, saturated diamond profile, Petersen alignment and literal pair transfer',
        'source_sha256': sha(Path(__file__)),
    }
    target = W / 'tuza_degree10_c5_final_scope_gate.json'
    pending = target.with_suffix('.pending')
    pending.write_text(json.dumps(report,indent=2)+'\n')
    pending.replace(target)
    print(json.dumps({'status':report['status'],'bound_c5_files':len(bound),'gate_sha256':sha(target),'peer_review_sha256':sb[peer.name],'standalone_subcubic_report_sha256':sha(sr_path)}),flush=True)


if __name__ == '__main__':
    main()
