"""Bind inherited endpoint-pair premises to immutable prior archive bytes."""
from pathlib import Path
from io import BytesIO
import hashlib
import json
import zipfile

root = Path('work')
archive = Path('outputs/tuza_degree9_verification.zip')
blob = archive.read_bytes()
assert hashlib.sha256(blob).hexdigest() == '45302825e120d3dae355438f9ec4ee536bf1c3ea89b25ec7c0d8030ec540c435'
expected = {}
notes = {}
for name in ['tuza_degree10_c6_lower_endpoint_transfer_audit.json', 'tuza_degree10_c7_old_lane_transfer_audit.json']:
    path = root/name
    data = path.read_bytes()
    notes[str(path)] = hashlib.sha256(data).hexdigest()
    expected.update(json.loads(data)['sources_sha256'])
expected.update({
    'tuza_degree9_common8_pair_probe.json': 'ab0667fbc30104918c5509bd69eefffaa67862b9ade6093bedac4dab91bb5a06',
    'tuza_degree9_common8_pair_check.py': 'df2f891967098a1a77cf04e0c97ab6aa19eeccd07bd02591a8e06e08ff9998b9',
    'tuza_degree9_high_lane_proof.txt': '50734026f8938a7abe8971195c5b80e9a377b2a127b7541ff54659932cc6b1ae',
})
records = {}
with zipfile.ZipFile(BytesIO(blob)) as outer:
    nested_name = 'outputs/tuza_degree8_verification.zip'
    inner_blob = outer.read(nested_name)
    with zipfile.ZipFile(BytesIO(inner_blob)) as inner:
        for name, expected_sha in expected.items():
            member = 'work/'+name
            if member in outer.namelist():
                data = outer.read(member)
                location = {'archive': str(archive), 'member': member}
            elif member in inner.namelist():
                data = inner.read(member)
                location = {'archive': str(archive), 'nested_member': nested_name, 'member': member}
            else:
                # A small optional compressed mixed-core source predates the
                # packaged active mixed source. Bind its actual current bytes.
                supplement = root/'tuza_degree10_old_transfer_supplement.zip'
                if supplement.exists():
                    with zipfile.ZipFile(supplement) as extra:
                        data = extra.read(member)
                    location = {'archive': str(supplement), 'member': member, 'not_in_prior_archive': True}
                else:
                    data = Path(member).read_bytes()
                    location = {'canonical_file': member, 'not_in_prior_archive': True}
            actual_sha = hashlib.sha256(data).hexdigest()
            assert actual_sha == expected_sha, (name, actual_sha, expected_sha)
            records[member] = {'sha256': actual_sha, 'bytes': len(data), **location}
out = {
    'result': 'PASS',
    'scope': 'Exact immutable-byte binding of inherited common-six and common-seven endpoint-pair premises, plus common-eight literal and human sparse premise',
    'archive': str(archive),
    'archive_sha256': hashlib.sha256(blob).hexdigest(),
    'archive_bytes': len(blob),
    'nested_degree8_archive_sha256': hashlib.sha256(inner_blob).hexdigest(),
    'literal_source_members_bound': len(records),
    'transfer_note_sha256': notes,
    'members': records,
    'checker_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'new_whole_domain_replay_claimed': False,
}
supplement = root/'tuza_degree10_old_transfer_supplement.zip'
if supplement.exists():
    data = supplement.read_bytes()
    out['supplement_archive_sha256'] = hashlib.sha256(data).hexdigest()
    out['supplement_archive_bytes'] = len(data)
path = root/'tuza_degree10_inherited_archive_bindings_verified.json'
path.write_text(json.dumps(out, indent=2))
print(json.dumps({'result': 'PASS', 'members': len(records), 'report': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}, indent=2))
